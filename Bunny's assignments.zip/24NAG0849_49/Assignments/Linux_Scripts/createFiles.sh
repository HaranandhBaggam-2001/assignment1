#!/bin/bash
mkdir TestDir1
cd TestDir1
for((i=1;i<11;i++)); do
filename="TestDir1/File$i.txt"
touch $filename

    echo "$filename" > "$filename"
done
echo "files created"
