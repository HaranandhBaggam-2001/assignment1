//linux script to extract all lines containing "ERROR".and using awk to print date  and time and error message  of each extracted line

#!/bin/bash
# Check if the correct number of arguments are provided
if [ "$#" -ne 1 ]; then
    echo "Usage: $0 logfile"
    exit 1
fi

logfile="$1"

# Use grep to extract lines containing "ERROR" and awk to print date, time, and message
grep "ERROR" "$logfile" | awk '{print $1, $2, $3}'