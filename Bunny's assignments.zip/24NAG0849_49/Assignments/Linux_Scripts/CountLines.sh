#!/bin/bash

countLines()
{
  filename=$1
  lines=$(wc -l < $filename)
  echo "Number of lines in the $filename  are $lines"
}



countLines $1
