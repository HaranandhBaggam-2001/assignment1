#!/bin/bash
if [ $#  -ne "$filename" ]; then
  echo "provide file name"
  exit 1
fi

filename=$1
if [ -e "$filename" ]; then
  echo "file exists in current directory"
else
  echo "file not exists"
fi
