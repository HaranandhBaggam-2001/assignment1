#!/bin/bash
debug=false

while getopts ":d" opt; do
  case ${opt} in
              d ) debug=true ;;
              \? ) echo "Usage: $0 [-d]"; exit 1;
  esac
done

dir="TestDir"
if [ -d "$dir" ]; then
  echo "error:Directory $dir already exists"
  exit 1
fi

mkdir "$dir" || { echo "error:unable to create directory $dir"; exit 1; }

for i in {1..10}; do
   filename=$dir/File$i.txt"
   echo "$filename" > "$filename" || { echo "error:unable to create file $filename"; exit 1; }
   if [ "$debug" = true ]; then
       echo "created $filename"
   fi
done