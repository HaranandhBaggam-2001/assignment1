//Replacing text
#!/bin/bash

# Check if the correct number of arguments are provided
if [ "$#" -ne 2 ]; then
    echo "Usage: $0 input_file output_file"
    exit 1
fi

input_file="$1"
output_file="$2"

# Perform the replacement using sed
sed 's/old_text/new_text/g' "$input_file" > "$output_file"

echo "Replacement complete. Output saved to $output_file."
