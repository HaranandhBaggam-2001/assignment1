#!/bin/bash

while true ;
do
 echo "enter number"
 read a
 if [ $a -eq 0 ]; then
   break;

 elif [[ $a%2 -eq 0 ]]; then
   echo "$a is even"
 else
   echo "$a is odd"
  fi
done
