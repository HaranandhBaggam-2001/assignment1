package com.coreJava.assignments;

public class SavingsAccount extends Account {

	public SavingsAccount(double balance) {
		super(balance);
		
	}
	@Override
	public void calculateInterest()
	{
		double interestRate=1.50;
		double interestAmount=balance*interestRate;
		System.out.println("Interest calcualted for savings account:"+interestAmount);
	}
 
}
