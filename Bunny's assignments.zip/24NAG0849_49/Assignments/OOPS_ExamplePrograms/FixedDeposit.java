package com.coreJava.assignments;

public class FixedDeposit extends Account{
	
	public FixedDeposit(double balance) {
		super(balance);
		
	}

	@Override
	public void calculateInterest()
	{
		double interestRate=4.75;
		double interestAmount=balance*interestRate;
		System.out.println("Interest calcualted for savings account:"+interestAmount);
	}

}
