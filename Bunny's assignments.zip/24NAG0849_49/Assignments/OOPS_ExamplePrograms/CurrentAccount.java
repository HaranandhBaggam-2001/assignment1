package com.coreJava.assignments;

public class CurrentAccount extends Account{

	public CurrentAccount(double balance) {
		super(balance);
		
	}
	@Override
	public void calculateInterest()
    {
    	System.out.println("The important feature of current account is that it bears no interest at all");
    }

}
