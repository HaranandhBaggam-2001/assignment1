package com.coreJava.assignments;

public class BankingSystem {

	public static void main(String[] args) {
		Account account1=new SavingsAccount(4000);
		Account account2=new CurrentAccount(7000);
	    Account account3=new FixedDeposit(50000);
	    
	    //savings account operations
	    account1.deposit(5000);
	    account1.withdrawal(4000);
	    account1.calculateInterest();
	    
	    //current account operations
	    account2.deposit(3000);
	    account2.withdrawal(500);
	    account2.calculateInterest();
	    
	    //fixed deposit account operations
	    account3.deposit(12000);
	    account3.withdrawal(10000);
	    account3.calculateInterest();
	    
	}

}
