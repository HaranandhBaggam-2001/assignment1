package com.coreJava.assignments;

public class UserMainCode2 {
	public static int sumOfSquaresOfEvenDigits(int num)
	{
	  int sumOfEvenDigitsSquares=0;
	  while(num>0)
	  {
		  int digit=num%10;
		  if(digit%2==0)
		  {
			  sumOfEvenDigitsSquares += digit*digit;
		  }
		  num/=10;
	  }
	  return sumOfEvenDigitsSquares;
	}

}
