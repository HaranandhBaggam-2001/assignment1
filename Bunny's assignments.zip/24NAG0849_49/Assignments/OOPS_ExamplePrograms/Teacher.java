package com.coreJava.assignments;

public class Teacher extends Staff {
	private String subject;
	public Teacher(String name, int age, String contact,String subject) {
		super(name, age, contact);
		this.subject=subject;
		
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	

}
