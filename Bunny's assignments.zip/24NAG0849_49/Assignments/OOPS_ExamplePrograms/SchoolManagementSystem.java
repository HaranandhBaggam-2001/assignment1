package com.coreJava.assignments;

public class SchoolManagementSystem
 {

	public static void main(String[] args) {
		Teacher t1=new Teacher("Anitha",30, "anitha304@gmail.com","Telugu");
		System.out.println("Teacher details:\nname:"+t1.getName()+"\t"+
				            "\nage:"+t1.getAge()+"\t"+
				            "\ncontact:"+t1.getContact()+"\t"+
				            "\nsubject:"+t1.getSubject());
		AdministrativeStaff as1=new AdministrativeStaff("Suresh",28,"suresh562gmail.com","Administrator");
		System.out.println("Administrativestaff information \nName:"+as1.getName()+"\t"+
		                    "\nage:"+as1.getAge()+"\t"+
				            "\ncontact info: "+as1.getContact()+"\t"+
		                    "\nRole: "+as1.getRole());
		SupportStaff ss1=new SupportStaff("Amar", 32,"AmarIt@gmail.com", "Finance");
		System.out.println("Supporstaff Details \nname:"+ss1.getName()+"\t"+
				"\nage:"+ss1.getAge()+"\t"+
	            "\ncontact info: "+ss1.getContact()+"\t"+
                "\nDepartment: "+ss1.getDepartment());

	}

}
