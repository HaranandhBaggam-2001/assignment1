package com.coreJava.assignments;

public class AdministrativeStaff extends Staff {
	private String role;
	public AdministrativeStaff(String name, int age,String contact,String role) {
		super(name, age, contact);
		this.role=role;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}

	
}
