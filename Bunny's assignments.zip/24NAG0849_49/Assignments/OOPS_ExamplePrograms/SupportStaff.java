package com.coreJava.assignments;

public class SupportStaff extends Staff {
  String department;
	public SupportStaff(String name, int age, String contact,String department) {
		super(name, age, contact);
		this.department=department;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
 
}
