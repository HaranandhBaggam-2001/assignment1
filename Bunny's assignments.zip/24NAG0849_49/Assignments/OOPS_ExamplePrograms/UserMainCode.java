package com.coreJava.assignments;


public class UserMainCode {
	
	static int checkSum(int num)
	{
		 int sumOfOddDigits=0;
		while(num>0)
		{
			int digit=num%10;
			if(digit%2!=0)
			{
				sumOfOddDigits += digit;
			}
			num /=10;
			
		}
		if(sumOfOddDigits%2!=0)
		{
			return 1;
		}
		else
		{
		
		return -1;
		}
	}
}
