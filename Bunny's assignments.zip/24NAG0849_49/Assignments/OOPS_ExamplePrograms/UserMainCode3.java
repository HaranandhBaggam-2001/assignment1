package com.coreJava.assignments;

public class UserMainCode3 {
	public static int reverseNumber(int num)
	{
	int reversednum=0;
	while(num>0)
	{
		int digit=num%10;
		reversednum=reversednum*10+digit;
		num /= 10;
		
	}
	return reversednum;
	}

}
