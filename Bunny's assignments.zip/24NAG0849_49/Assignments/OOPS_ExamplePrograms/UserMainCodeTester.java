package com.coreJava.assignments;

import java.util.Scanner;

public class UserMainCodeTester {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("enter a number");
		int number=sc.nextInt();
		int res=UserMainCode.checkSum(number);
		System.out.println(res);
		
	}

}
