package com.coreJava.assignments;

public class Account {
	double balance;

	public Account(double balance) {
		super();
		this.balance = balance;
	}
    public void deposit(double amount)
    {
    	balance += amount;
    	System.out.println("The total balance after depositing "+amount+" successfully:"+balance);
    }
    public void withdrawal(double amount)
    {
    	if(amount>balance)
    	{
    		System.out.println("Insufficient funds");
    	}
    	else
    	{
    		balance -=amount;
    		System.out.println("The total balance after withdrawing "+amount+" successfully:"+balance);
        }
    }
    public void calculateInterest()
    {
    	System.out.println("Interest calculated based on the type of account");
    }
}
