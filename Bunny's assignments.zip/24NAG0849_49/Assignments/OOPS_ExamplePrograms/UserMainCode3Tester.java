package com.coreJava.assignments;

import java.util.Scanner;

public class UserMainCode3Tester {

	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);		
		System.out.println("enter a number");
		int number=sc.nextInt();
		int res=UserMainCode3.reverseNumber(number);
		System.out.println("reversed number:"+res);     

	}

}
