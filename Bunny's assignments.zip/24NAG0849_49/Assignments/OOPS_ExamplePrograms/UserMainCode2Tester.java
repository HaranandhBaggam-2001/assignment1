package com.coreJava.assignments;

import java.util.Scanner;

public class UserMainCode2Tester {

	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
		
		System.out.println("enter a number");
		int number=sc.nextInt();
		int res=UserMainCode2.sumOfSquaresOfEvenDigits(number);
		System.out.println("sum of even digits squares of a positive integer:"+res);
		System.out.println();

	}

}
