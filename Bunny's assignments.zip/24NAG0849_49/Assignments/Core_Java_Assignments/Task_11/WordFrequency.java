package com.examples.iostreams.bufferedstreams;
import java.io.*;
import java.util.*;

public class WordFrequencyCounter {
    public static void main(String[] args) {
        // Specify the input and output file paths
        String inputFilePath = "C:\\Users\\Administrator\\Desktop\\Amulya\\data\\input.txt";
        String outputFilePath = "C:\\Users\\Administrator\\Desktop\\Amulya\\data\\output.txt";

        // Map to store the frequency of each word
        Map<String, Integer> wordFrequencyMap = new HashMap<>();

        // Read the input file and count word frequencies
        try (FileReader fileReader = new FileReader(inputFilePath);
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                // Split the line into words
                String[] words = line.split("\\W+");
                for (String word : words) {
                    if (!word.isEmpty()) {
                        word = word.toLowerCase(); // Convert to lower case for uniformity
                        wordFrequencyMap.put(word, wordFrequencyMap.getOrDefault(word, 0) + 1);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading the input file: " + e.getMessage());
        }

        // Write the word frequencies to the output file
        try (FileWriter fileWriter = new FileWriter(outputFilePath);
             BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {

            for (Map.Entry<String, Integer> entry : wordFrequencyMap.entrySet()) {
                bufferedWriter.write(entry.getKey() + ": " + entry.getValue());
                bufferedWriter.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error writing to the output file: " + e.getMessage());
        }

        System.out.println("Word frequency count completed. Check the output file for results.");
    }
}