package com.coreJava.lambdasDay12;

import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.function.Consumer;
public class PersonFunctionalInterfaces {

	public static void main(String[] args) {
		Person person=new Person("Alice",30);
        //Predicate
		Predicate<Person> isAdult=p->p.getAge() >=18;
		//Function
		Function<Person,String> getNameUpperCase=p->p.getName().toUpperCase();
		//Consumer
		Consumer<Person> printDetails=p -> System.out.println("person details:"+p);
		//Supplier
		Supplier<Person> newPersonSupplier=()->new Person("Amulya",23);
		
		System.out.println("the person is adult?"+isAdult.test(person));
		System.out.println("name in upper case: "+getNameUpperCase.apply(person));
		printDetails.accept(person);
		
		System.out.println("new person entry: "+newPersonSupplier.get());
		
	}

}
