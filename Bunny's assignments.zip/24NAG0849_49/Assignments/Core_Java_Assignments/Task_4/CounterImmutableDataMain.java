package com.multithreading.examples.childThreads;

public class CounterImmutableDataMain {

	public static void main(String[] args) {
		Counter counter=new Counter();
		Runnable incrementTask=() ->{
			for(int i=0;i<1000;i++)
			{
				counter.increment();
			}
		};
		Runnable decrementTask=() -> {
			for(int i=0;i<1000;i++)
			{
				counter.decrement();
			}
		};
		Thread incrementThread=new Thread(incrementTask);
		Thread decrementThread=new Thread(decrementTask);
		incrementThread.start();
		decrementThread.start();
		try {
			incrementThread.join();
			decrementThread.join();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}System.out.println("final count: "+counter.getCount());
		
		ImmutableData data=new ImmutableData(42);
		Runnable readTask=() ->{
			System.out.println("value read from immutable data: "+data.getValue());
		};
		Thread readt1=new Thread(readTask);
		Thread readt2=new Thread(readTask);
		readt1.start();
		readt2.start();
		

	}

}
