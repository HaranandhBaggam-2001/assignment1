package com.multithreading.examples.childThreads;

public class ImmutableData {
	private final int value;
	public ImmutableData(int value) {
		super();
		this.value = value;
	}

	public int getValue()
	{
		return value;
	}
	

}
