package com.multithreading.examples.childThreads;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PrimeConcurrentCollections {

	public static void main(String[] args) {
		int numberToCheck=100;
		int numThreads=4;
		
		ExecutorService executor=Executors.newFixedThreadPool(numThreads);
		List<CompletableFuture<Integer>> futures=new ArrayList<>();
		for(int i=0;i<numThreads;i++)
		{
			int start=i*(numberToCheck/numThreads)+1;
			int end=(i+1)*(numberToCheck/numThreads);
			CompletableFuture<Integer> future=CompletableFuture.supplyAsync(()->calculatePrimesInRange(start,end),executor);
			futures.add(future);

		}
		CompletableFuture<Void> allDone=CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
				.thenAcceptAsync(result->{
					try (FileWriter fw=new FileWriter("C:\\Users\\Administrator\\Desktop\\Amulya\\output.txt")){
						for(CompletableFuture<Integer> future:futures)
						{
							fw.write(future.join()+"\n");
						}
						
					}
				catch(IOException e) {
					e.printStackTrace();
				}
	},executor);
	allDone.join();
	executor.shutdown();
	
}

	private static boolean isPrime(int n)
	{
		if(n<=1)
		{
			return false;
		}
		for(int i=2;i<=Math.sqrt(n);i++)
		{
			if(n%i==0)
			{
				return false;
			}
		}
		return true;
	}
	private static int calculatePrimesInRange(int start,int end)
	{
		int count=0;
		for(int i=start;i<=end;i++)
		{
			if(isPrime(i)) {
				count++;
			}
		}
		return count;
	}



}
