package com.multithreading.examples;

public class BankAccount {
	private double balance;
	public BankAccount(double initialBalance) {
		super();
		balance = initialBalance;
	}
	public synchronized void deposit(double amount)
    {
    	balance += amount;
    	System.out.println("The total balance after depositing "+amount+" successfully:"+balance);
    }
    public synchronized void withdrawal(double amount)
    {
    	if(amount>balance)
    	{
    		System.out.println("Insufficient funds");
    	}
    	else
    	{
    		balance -=amount;
    		System.out.println("The total balance after withdrawing "+amount+" successfully:"+balance);
        }
    }
    public synchronized double getBalance()
    {
    	return balance;
    }
    
	

}
