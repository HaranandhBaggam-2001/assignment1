package com.multithreading.examples;

public class TransactionThread extends Thread{
	private BankAccount account;
	private boolean isDeposit;
	private double amount;
	public TransactionThread(BankAccount account, boolean isDeposit, double amount) {
		super();
		this.account = account;
		this.isDeposit = isDeposit;
		this.amount = amount;
	}
	public void run()
	{
		if(isDeposit)
		{
			account.deposit(amount);
		}else {
			account.withdrawal(amount);
		}
	}

}
