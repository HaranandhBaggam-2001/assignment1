package com.multithreading.examples;

public class BankOperations {

	public static void main(String[] args) {
		BankAccount account=new BankAccount(5000);
		TransactionThread[] threads=new TransactionThread[5];
		for(int i=0;i<threads.length;i++)
		{
		//alternate deposits and withdrawals
			threads[i]=new TransactionThread(account,i%2==0,500);
			
		}
		for(TransactionThread thread:threads)
		{
			thread.start();
		}
		for(TransactionThread thread:threads)
		{
		   try {
			   thread.join();
		   }catch(InterruptedException e) {
			  e.printStackTrace();
		   }
		   System.out.println("final balance in account:"+account.getBalance());
		}
	}
}
