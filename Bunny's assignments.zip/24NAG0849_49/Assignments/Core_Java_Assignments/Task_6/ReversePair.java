package com.genericsExamples;

public class ReversePair {

	public static void main(String[] args) {
		Pair<Integer,String> p=new Pair(5,"Amulya");
		Pair<String,Integer> rev=p.reverse();
		System.out.println(rev.getSecond()+" "+rev.getFirst());
	}

}
