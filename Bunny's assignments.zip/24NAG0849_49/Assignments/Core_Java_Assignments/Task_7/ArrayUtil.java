package com.genericsExamples;

import java.util.Arrays;

public class ArrayUtil {

	public static void main(String[] args) {
		//integer array swapping
		Integer[] intArray= {3,4,5,7,9};
		System.out.println("before swapping: "+Arrays.toString(intArray));
		Swapping.swap(intArray,3,7);
		System.out.println("after swapping: "+Arrays.toString(intArray));
//string array swapping
		String[] strArray= {"apple","ball","car","doll","eagle"};
		System.out.println("before swapping: "+Arrays.toString(strArray));
		Swapping.swap(intArray,0,3);
		System.out.println("after swapping: "+Arrays.toString(strArray));
	}

}
