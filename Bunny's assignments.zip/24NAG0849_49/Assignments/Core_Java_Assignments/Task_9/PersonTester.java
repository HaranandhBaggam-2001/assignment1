package com.coreJava.lambdasDay12;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class PersonTester {

	public static void main(String[] args) {
		List<Person> people=new ArrayList<>();
		people.add(new Person("amulya",23));
		people.add(new Person("akanksha",20));
		people.add(new Person("sunitha",37));
		people.add(new Person("srinivas",42));
		Comparator<Person> ageComparator=(Person p1,Person p2) ->Integer.compare(p1.getAge(),p2.getAge());
	    people.sort(ageComparator);
	    people.forEach(System.out::println);
	}

}
